function createBunny(x, y, text, app)
{
    // create our little bunny friend..
    this.text = text;
    this.app = app;
    var line = new PIXI.Text(this.text);

    // enable the bunny to be interactive... this will allow it to respond to mouse and touch events
    line.interactive = true;

    // this button mode will mean the hand cursor appears when you roll over the bunny with your mouse
    line.buttonMode = true;

    // center the bunny's anchor point
    line.anchor.set(0.5);

    // setup events
    line
        // events for drag start
        .on('mousedown', onDragStart)
        .on('touchstart', onDragStart)
        // events for drag end
        .on('mouseup', onDragEnd)
        .on('mouseupoutside', onDragEnd)
        .on('touchend', onDragEnd)
        .on('touchendoutside', onDragEnd)
        // events for drag move
        .on('mousemove', onDragMove)
        .on('touchmove', onDragMove);

    // move the sprite to its designated position
    line.position.x = x;
    line.position.y = y;

    // add it to the stage
    this.app.stage.addChild(line);
}

function onDragStart(event)
{
    // store a reference to the data
    // the reason for this is because of multitouch
    // we want to track the movement of this particular touch
    this.data = event.data;
    this.alpha = 0.5;
    this.dragging = true;
}

function onDragEnd()
{
    this.alpha = 1;

    this.dragging = false;

    // set the interaction data to null
    this.data = null;
}

function onDragMove()
{
    if (this.dragging)
    {
        var newPosition = this.data.getLocalPosition(this.parent);
        this.position.x = newPosition.x;
        this.position.y = newPosition.y;
    }
}
window.onload = function(){
    var app = new PIXI.Application(800, 600, {backgroundColor : 0x1099bb});
    document.body.appendChild(app.view);
    
    // create the root of the scene graph
    var stage = new PIXI.Container();
    
    // create a texture from an image path
    var text = "Yarrağımı ye Fener!"
    
    for (var i = 0; i < 10; i++)
    {
        createBunny(Math.floor(Math.random() * 800) , Math.floor(Math.random() * 600), text, app);
    }
    
}
